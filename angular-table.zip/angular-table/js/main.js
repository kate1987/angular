function TabController($scope) {


  var sam_tab = {
           
            tab_number: 10,
           
              items:[ {qty:5, description:'Название1', cost:10}]};

  if(localStorage["tab"] == "" || localStorage["tab"] == null){
    $scope.tab = sam_tab;
  }
  else{
    $scope.tab =  JSON.parse(localStorage["tab"]);
  }
    $scope.addItem = function() {
        $scope.tab.items.push({qty:0, cost:0, description:""});    
    }
   


    $scope.removeItem = function(item) {
        $scope.tab.items.splice($scope.tab.items.indexOf(item), 1);    
    }
    
	
	

	
    $scope.tab_sub_total = function() {
        var total = 0.00;
        angular.forEach($scope.tab.items, function(item, key){
          total += (item.qty * item.cost);
        });
        return total;
    }



    $scope.printInfo = function() {
      window.print();
    }

    $scope.clearLocalStorage = function(){
      var confirmClear = confirm("Вы уверены что хотите обнулить таблицу?");
      if(confirmClear){
        localStorage["tab"] = "";
        $scope.tab = sam_tab;
      }
    }


};

angular.module('jqanim', []).directive('jqAnimate', function(){ 
  return function(scope, instanceElement){ 
      setTimeout(function() {instanceElement.show('slow');}, 0); 
  } 
});

function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#company_logo').attr('src', e.target.result);
        }
        reader.readAsDataURL(input.files[0]);
    }
}


$(document).ready(function(){
  $("#tab_number").focus();
  $("#imgInp").change(function(){
    readURL(this);
  });
});